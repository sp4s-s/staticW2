# Glitch animation with pseudo-element

A Pen created on CodePen.io. Original URL: [https://codepen.io/oscar-jite/pen/VwRbdKB](https://codepen.io/oscar-jite/pen/VwRbdKB).

